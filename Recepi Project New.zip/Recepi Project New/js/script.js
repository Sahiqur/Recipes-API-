//dom element
const food_element=document.getElementById("food_element");
const view_details=document.getElementById("view_details");
const model_element=document.getElementById("model_element");
const search=document.getElementById("search");
const button_Class=document.getElementById("button");
const View_Details=document.getElementById("View_Details");

//function
async function initialLoad(){
    const Apiurl = `https://www.themealdb.com/api/json/v1/1/search.php?s`;
    const foods=await getData(Apiurl);
    showFood(foods.meals);
    
}

async function getData(Apiurl){
    try {
        const  res= await fetch(Apiurl);
        const data=await res.json();
        return data;
    } catch (error) {
        console.log(error);
    }
}

function showFood(foods){
    let foodItem="";

    foods.forEach(food => {
        const foodHtml=`<div class="item">
                <div class="food-item">
                    <figure>
                        <img src=${food.strMealThumb} alt="" width="280" height="250" class="image_radis">
                    </figure>
        
                    <div class="card-body">
                        <h2 class="card-title">${food.strMeal}</h2>
                        <p>${food.strInstructions.slice(0,90)}</p>
            
                        <div class="card-action">
                            <label for="my-modal-6" onclick="modal(${food.idMeal})" class="view-details" id="View_Details">
                                View Details
                            </label>
                        </div>
                    </div>

                </div>

                
            </div>
        `;
        foodItem=foodItem+foodHtml;
        
    });
    food_element.innerHTML=foodItem;
    
}


async function SearchFood(){
    food_element.innerHTML="";
    const searchKeyword=search.value;
    const Apiurl=`https://www.themealdb.com/api/json/v1/1/search.php?s=${searchKeyword}`;
    const foods=await getData(Apiurl);
    if(foods.meals===null){
        return (food_element.innerHTML="<h1 class=`text-3xl`>No Food Found</h1>");
    }
    showFood(foods.meals);
}

async function modal(id){
    const Apiurl = `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`;
    const food=await getData(Apiurl)
    document.getElementById("food_element").innerHTML=`<div id="item_element">
                <figure>
                    <img src=${food.meals[0].strMealThumb} alt="" width="700" height="500" class="image_radis" >
                </figure>
                <div id="title_element">
                    <p>${food.meals[0].strInstructions}</p>
                </div>
                <button class="btn_back" id="btn_back"><a href="file:///c%3A/Users/USER/Recepi%20Project%20New/index.html">Close</a></button>
            </div>
            `;
}

//event listener 
window.addEventListener("load",initialLoad);
button_Class.addEventListener("click",SearchFood);
View_Details.addEventListener("click",modal);
